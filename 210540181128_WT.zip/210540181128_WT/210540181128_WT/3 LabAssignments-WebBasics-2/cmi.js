
function in2cm(inch)
	{
		var cm = 2.54 * inch
		document.write(+inch+" inch = "+cm+" cm");
		alert(+inch+" inch = "+cm+" cm");
	}