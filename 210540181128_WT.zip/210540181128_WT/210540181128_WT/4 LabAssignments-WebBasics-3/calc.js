exports.add = function(a, b){
    console.log(`${a} + ${b} = ${a+b}`);
}
exports.subtract = function(a, b){
    console.log(`${a} - ${b} = ${a-b}`);
}
exports.multiply = function(a, b){
    console.log(`${a} * ${b} = ${a*b}`);
}
exports.divide = function(a, b){
    console.log(`${a} / ${b} = ${a/b}`);
}
exports.square = function(a){
    console.log(`square of  ${a} = ${a*a}`);
}
exports.sum = function(a, b, c){
    console.log(`${a} + ${b} + ${c} = ${a+b+c}`);
}