exports.factorial = function(a){
    var fact = 1;
    for(var i=1 ; i<=a; i++){
         fact = fact * i;  
     }
    console.log(`factorial = ${fact}`);
}

exports.myprime = function(a){
    let flag = true;
    if(a == 1){
        console.log(`${a} is prime`);
    }
    else if(a > 1){
        for(var i=2; i<a; i++){
            if(a % i == 0){
                flag = false;
                break;
            }
        }
        if(flag)
            console.log(`${a} is prime`);
        else
            console.log(`${a} is not prime`);
    }
}

exports.table = function(a){
    var i=1;
    while(i<=10){
        console.log(`${a} * ${i} = ${a*i}`);
        i++;
    }
}