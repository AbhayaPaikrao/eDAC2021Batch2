var fs = require("fs")

var arr = ["Sachin","Saurabh","Sulakshan","Neha","Prachi"];
    console.log(arr);
        var newArr = arr.join(" | ");
            console.log(newArr);

fs.writeFile("names.txt", newArr, function(err){
    if(err) throw error;
});
    console.log("done");