var fs = require("fs");

fs.open("emp.txt", 'r+', function(err, fd){
    if(err) throw err;

    var buf = Buffer.alloc(1000);
        fs.read(fd, buf, 0, buf.length, 0, function(err, bytes){
            if(err) throw err;
            
                if(bytes>0){
                    var salarySum=0;
                        for(emp of buf.toString().split("\n")){
                            Emp = emp.split(":")
                                salarySum += parseInt(Emp[3]);
                            console.log("salary of "+Emp[1]+" : "+salarySum);
                        }
                    console.log("sum of salary : "+salarySum);
                }
            fs.close(fd, function(err){
                if(err) throw err;
            })
        });
});