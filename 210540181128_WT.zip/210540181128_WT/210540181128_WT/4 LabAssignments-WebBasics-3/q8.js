var fs = require("fs");

var empData = ['1001 : MAULI : 20000',
            '1002 : ADI : 30000',
            '1003 : SANDIP : 35000',
            '2001 : SHIV : 30000',
            '2002 : ANAND : 35000']

empArr = "";
for (i of empData){
    empArr += i + '\n';
}
fs.writeFile("empData.txt", empArr, function(err){
    
    if (err) throw err;

});
    console.log("done");