exports.calcArea = function(length,breadth){
    var area = length * breadth;
    console.log(`Area of Rectangle : ${area}`);
}

exports.calcPerimeter = function(length,breadth){
    var Perimeter = 2 * (length + breadth)
    console.log(`Perimeter of Rectangle : ${Perimeter}`);
}