exports.palindrome = function(str){
    var str2 = str.split("").reverse().join();
        if(str == str2){
            console.log("palindrome");
        }
        else{
            console.log("not palindrome");
        }
}

exports.upper = function(str){
    str2 = str.toUpperCase();
    console.log(str2);
}

exports.search = function(){
    var count = 0;
        var arr = ["www.google.com","www.msn.com","www.amazon.com","www.coderanch.com","in.answers.yahoo.com","en.m.wikipedia.com","codehs.gitbooks.io"];
        var sites = arr.filter(e1=> e1.startsWith('www'));
            count = sites.length;

    console.log(sites)
    console.log(`total is ${count}`)
}