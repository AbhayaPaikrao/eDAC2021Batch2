var greetme = require("./greet");

    console.log(greetme.greet() + " Sachin..!");
