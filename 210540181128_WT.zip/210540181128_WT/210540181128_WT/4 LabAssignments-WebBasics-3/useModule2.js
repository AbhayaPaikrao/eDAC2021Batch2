var calculate = require("./calc.js");

var a = 95;
var b = 11;
var c = 13;

calculate.add(a,b);
calculate.subtract(a,b);
calculate.multiply(a,b);
calculate.divide(a,b);
calculate.square(b);
calculate.square(c);
calculate.sum(a,b,c);