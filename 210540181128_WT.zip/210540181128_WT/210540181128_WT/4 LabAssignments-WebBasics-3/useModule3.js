var func = require("./mymodule.js");

var a = 13;

console.log("number = "+a);

func.factorial(a);
func.myprime(a);
func.table(a);