var shape = require("./Module4")

console.log("Circle");
    var rad = 5;
        shape.cArea(rad);
        shape.cCircumference(rad);
        shape.cDiameter(rad);

console.log("Rectangle");
    var l=5, b=8;
        shape.rArea(l, b);
        shape.rPerimeter(l, b);

console.log("Triangle");
    var a=2, b=2, c=2;
        shape.isEqui(a,b,c);
        shape.tPerimeter(a,b,c);