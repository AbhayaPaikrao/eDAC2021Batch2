var str = require("./strings.js")

var urstring = "Sachin Rane"
    console.log(urstring);

    str.palindrome(urstring);
    str.upper(urstring);
    str.search();