import React, {Component} from 'react'
import './App.css';
import NewsHeader from './NewsHeader/NewsHeader';
import NewsContent from './NewsContent/NewsContent';

var news1= 'WhatsApp is working on a new Flash Calls feature for Android';
var content1= 'WhatsApp is introducing a new feature that will allow you to log into WhatsApp quickly according to a report by WABetaInfo. The new feature which is in development is called Flash Calls and is currently in the WhatsApp beta for the Android 2.21.11.7 update. Flash Calls will allow users to quickly get verified while logging into WhatsApp via an automatic verification over a call.';

var news2= 'Battlegrounds Mobile India ban news: Lok Sabha MP demands scrutiny of Krafton-Tencent relationship';
var content2= 'Battlegrounds Mobile India launch is inching close and the hype surrounding the game is reaching new levels with every teaser image/video that the company posts on its special media handles. As much as the launch is anticipated, there are also calls on a Battlegrounds Mobile India ban from politicians. This time, Nizamabad, Telangana, Lok Sabha MP, Arvind Dharampuri has written to IT Minister Ravi Shankar Prasad regarding the Battlegrounds Mobile India launch. The letter was sent on June 2nd mentioned that Dharampuri has received a representation against the game by Nizamabad-based social activist Sai Kumar, according to Zee News.';

var news3= 'WhatsApp Fast Playback for voice messages: What it is and how to use it';
var content3= 'WhatsApp introduced a new feature that lets users choose between multiple playback speeds while playing an audio file. The new options let you listen to longer voice messages easily and can also be used to skip through large messages to get to a particular point. This helps make the most of long voice messages, where it can sometimes be time-consuming to go through the entire message without skipping on any details. The latest WhatsApp update for Android and iOS changes that with the introduction of WhatsApp’s new  Fast Playback speeds. There are two new playback speeds offered in the feature, taking the number of playable speeds to three. These include 1X, the default, original playback speed, along with 1.5X and 2X, which let you play the file at 5-% or 100% faster speeds. Here’s how you can easily use both new speeds.';


class App extends Component{
  state = {
    news:[{headline:news1, content:'read more'},
          {headline:news2, content:'read more'},
          {headline:news3, content:'read more'}
    ]
  }
  newsHandler1 = () => {
    this.setState({
      news:[{headline:news1, content:content1},
            {headline:news2, content:'read more'},
            {headline:news3, content:'read more'}
      ]
    });
  }
  newsHandler2 = () => {
    this.setState({
      news:[{headline:news1, content:'read more'},
            {headline:news2, content:content2},
            {headline:news3, content:'read more'}
      ]
    });
  }
  newsHandler3 = () => {
    this.setState({
      news:[{headline:news1, content:'read more'},
            {headline:news2, content:'read more'},
            {headline:news3, content:content3}
      ]
    });
  }

  render(){
    return(
      <div className="App">
          <NewsHeader/>
          <div>
          <NewsContent title={this.state.news[0].headline} body={this.state.news[0].content} click={this.newsHandler1}/>
          </div><div>
          <NewsContent title={this.state.news[1].headline} body={this.state.news[1].content} click={this.newsHandler2}/>
          </div><div>
          <NewsContent title={this.state.news[2].headline} body={this.state.news[2].content} click={this.newsHandler3}/>
          </div>
      </div>
    );
  }
}

export default App;
