import React from 'react';
import "./NewsContent.css";

var NewsContent = (props) => {
    return (
        <div className="NewsContent">
                <h3>{props.title}</h3>
                <p onClick={props.click}>{props.body}</p>
        </div>
    );
}
export default NewsContent;