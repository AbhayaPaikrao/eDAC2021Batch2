import React from 'react';
import './NewsHeader.css';
var NewsHeader = (props) => {
    return (
        <div className='NewsHeader'>
            <h1 className='text'>HEADLINES</h1>
        </div>
    );
}
export default NewsHeader;